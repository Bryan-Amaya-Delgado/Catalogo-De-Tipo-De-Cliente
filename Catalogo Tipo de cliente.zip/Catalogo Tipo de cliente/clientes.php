<?php 

include("con_db.php");

if (isset($_POST['register'])) {
    if (strlen($_POST['clave']) >= 1 && 
    	strlen($_POST['nombre']) >= 1 && 
    	strlen($_POST['descripcion']) >= 1 && 
    	strlen($_POST['clientes'])) {
	    
	    	$clave = trim($_POST['clave']);
	    	$nombre = trim($_POST['nombre']);
	    	$descripcion = trim($_POST['descripcion']);
	    	$clientes = trim($_POST['clientes']);
	    	$fechareg = date("d/m/y");
	    	$consulta = "INSERT INTO datos(clave, nombre, descripcion, clientes , fechareg) VALUES ('$clave','$nombre', '$descripcion', '$clientes', '$fechareg')";
	    	
	    $resultado = mysqli_query($conex,$consulta);
	    if ($resultado) {
	    	?> 
	    	<h3 class="ok">Se completó tu registro correctamente</h3>
           <?php
	    } else {
	    	?> 
	    	<h3 class="bad">Ups ha ocurrido un error</h3>
           <?php
	    }
    }   else {
	    	?> 
	    	<h3 class="bad">Por favor complete los campos</h3>
           <?php
    }
}

?>